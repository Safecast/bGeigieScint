/************************************************************************
 * configure.h
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * this is the main configuration header file for the chip45boot3 bootloader
 * note: many of the definitions here can be overriden by -DHOST_USART=... symbol
 * in the Studio 6 project settings (Project -> Properties -> C-Compiler -> Defined Symbols)
 ************************************************************************/


#ifndef CONFIGURE_H_

	#define CONFIGURE_H_

	// The following macros should be defined in project settings (toolchain->compiler->symbols)

	// set the application start address
	//	#define APPLICATION_START_ADDRESS 0x1000
	
	// define which functions should be compiled into the bootloader	
	// 	#define PROVIDE_FIRMWARE_VERSION
	// 	#define PROVIDE_FLASH_WRITE
	// 	#define PROVIDE_FLASH_READ
	// 	#define PROVIDE_RWW_WRITE
	// 	#define PROVIDE_RWW_READ


	// bootloader version is V1.0, this version can be read out from the PC GUI, set to your linking
	#define VERSION_MAJOR 1
	#define VERSION_MINOR 0

	
	// if encryption should be use, check if the key is defined in Project -> Properties -> C-Compiler -> Defined Symbols)
	// example is here: ENCRYPTION_KEY={1936287828,1750365001,1635014757,2036681573}
	// make sure, that NO space characters are used for separation!
	#ifdef USE_ENCRYPTION
		#ifndef ENCRYPTION_KEY
			#error When using encrypted communication, ENCRYPTION_KEY has to be defined in project settings (toolchain -> c-compiler -> symbols).
		#endif
	#endif
	

	// the bootloader needs to know the application's start address, so we check if it was set in Project -> Properties -> C-Compiler -> Defined Symbols)
	#ifndef APPLICATION_START_ADDRESS
		#error APPLICATION_START_ADDRESS has to be defined!
	#endif

#endif /* CONFIGURE_H_ */
