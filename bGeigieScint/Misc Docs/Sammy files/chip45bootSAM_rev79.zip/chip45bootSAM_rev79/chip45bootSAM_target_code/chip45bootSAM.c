/************************************************************************
 * main.c
 * ======
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader featuring:
 * - USART automatic baud rate detection (comfortable)
 * - lightweight binary protocol (fast)
 * - strong 16 bit CRC checksum (reliable)
 * - optional 128 bit XTAE decryption (safe)
 * - can use standard USART
 * - bootloader can read out application firmware version
 *
 * see http://go.chip45.com/c45b3 for details
 *
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 *
 * COMPILER (TOOLCHAIN)
 * Atmel Studio 7
 *
 ************************************************************************/


/************************************************************************
 * includes
 ************************************************************************/
//#include <avr/pgmspace.h>
//#include <avr/interrupt.h>
#include <atmel_start.h>

#include "configure.h"
#include "startup.h"
#include "host.h"
#include "commands.h"
#include "timeout.h"

#ifdef USE_ENCRYPTION
	#include "xtae.h"
#endif

#include "autobaud.h"
#include "usart.h"


/************************************************************************
 * global variables
 ************************************************************************/
uint8_t buffer[HOST_BUFFER_LENGTH];  // __attribute__ ((section (".noinit")));


/************************************************************************
 * start the user application code
 ************************************************************************/
// https://community.atmel.com/forum/samd20g17-not-jumping-application-sam-ba-bootloader
// https://community.atmel.com/forum/bootloader-sam3x8c-jump-program

void startUserApplication(void)
{
	void (*user_code_entry)(void);

	unsigned *p;  // used for loading address of reset handler from user flash

	/* Change the Vector Table to the USER_FLASH_START
	in case the user application uses interrupts */
	// SCB->VTOR = (APPLICATION_START_ADDRESS & 0x1FFFFF80);
	SCB->VTOR = (APPLICATION_START_ADDRESS & SCB_VTOR_TBLOFF_Msk);//   0x1FFFFF80);
	
	/* SP (stack pointer) register must be set correctly before jump to the
	*  user application: http://www.keil.com/forum/17342/
	*/
	__set_CONTROL(0);  // not sure if this necessary, works with or without
	
	// https://community.arm.com/processors/f/discussions/4154/use-case-of-msp-and-psp-in-cortex-m
	// according to this link, MSP is the default stack pointer
	__set_MSP(*(uint32_t *) APPLICATION_START_ADDRESS);
	//__set_PSP(*(uint32_t *) APPLICATION_START_ADDRESS);

	// Load contents of second word of user flash - the reset handler address
	// in the applications vector table
	p = (unsigned *)(APPLICATION_START_ADDRESS + 4);

	// Set user_code_entry to be the address contained in that second word
	// of user flash
	user_code_entry = (void *) *p;

	// Jump to user application
	user_code_entry();
}


/************************************************************************
 * main program, here we go
 *
 * in: nothing
 * out: nothing
 ************************************************************************/
void userMain(void) {

	uint8_t length;
	uint8_t c;
	
	// check bootloader start condition
	if(!startupCheckStartCondition()) {
		
		startUserApplication();  // and start the application
	}
	#ifdef LED
		// LED on at start
		gpio_set_pin_level(LED, true);
	#endif
	

	// initialize and start the timeout function
	timeoutInit();


	if(hostInit() == 1) {

		// we don't need the timeout timer anymore, so we disable it
		timeoutDeInit();
			
	} else {

		// some error handling or we just start the application

		timeoutDeInit();
		#ifdef LED
			gpio_set_pin_level(LED,	false);  // LED off
		#endif
		startUserApplication();  // and start the application
	}
		
		
	// if we use encryption, we need to initialize the XTAE functions
	#ifdef USE_ENCRYPTION
		xtaeInit();
	#endif
	
	// forever...
	for(;;) {
		
		// wait for and receive a frame from the host
		length = hostBufferReceive(buffer);

		// did we really receive something?
		if(length > 0) {
	
			// if so, we parse the content for known commands and receive back the command byte incl. error bit (MSB)
			c = commandsParseBuffer(buffer, length);
				
			// shall we exit bootloader and start the application?
			if(c == CMD_START_APPLICATION) {
					
				hostDeInit();
				#ifdef LED
 					gpio_set_pin_level(LED,	false);  // LED off
				#endif
				startUserApplication();  // and start the application
				
			}
			
		
		}
	}

}


// end of file: main.c
