		/************************************************************************
 * usart.c
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * USART communication functions
 ************************************************************************/


/************************************************************************
 * include header files
 ************************************************************************/
// #include <avr/io.h>
// #include <avr/pgmspace.h>
#include <atmel_start.h>
#include <utils.h>

#include "configure.h"
#include "usart.h"


// struct io_descriptor *io_descr;


/************************************************************************
 * initialize the USART
 *
 * in : measured baud rate factor with (#define USE_AUTOBAUD) or just regular baud rate value
 * out: nothing
 ************************************************************************/
void usartInit(void) {

	// nothing to do here, init has already been done by Atmel Start code
}


/************************************************************************
 * de-initialize the USART, i.e. reset all registers to their initial values
 *
 * in : nothing
 * out: nothing
 ************************************************************************/
void usartDeInit(void) {

	USART_0_disable();

}


/************************************************************************
 * send a character to the USART
 *
 * in : the character
 * out: nothing
 ************************************************************************/
void usartPutChar(uint8_t c) {

	// wait until uart is ready to send
//  	while(!USART_0_is_byte_sent());
	
	// transmit the character
	USART_0_write_byte(c);

	// wait until transmit complete
 	while(!USART_0_is_byte_sent());

}


/************************************************************************
 * receive a character from the USART
 *
 * in : nothing
 * out: the character
 ************************************************************************/
uint8_t usartGetChar(uint8_t *c) {

	// check if a character has been received
	if(USART_0_is_byte_received()) {

		// read the character
		*c = USART_0_read_byte();

		// and return success
		return 1;

	} else {

		// return fail
		return 0;
	}

	return 0;  // to satisfy preprocessor
}

// end of file: usart.c
