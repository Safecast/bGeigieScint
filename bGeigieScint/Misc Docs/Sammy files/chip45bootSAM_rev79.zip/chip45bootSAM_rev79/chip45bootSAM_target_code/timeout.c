/************************************************************************
 * timeout.c
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * initializing the timeout system
 ************************************************************************/


/************************************************************************
 * include header files
 ************************************************************************/
// #include <avr/io.h>
#include <atmel_start.h>


/************************************************************************
 * initialize timeout
 * 
 * in : nothing
 * out: nothing
 ************************************************************************/
void timeoutInit(void) {

	// start the timer
	timer_start(&TIMER_0);
}


/************************************************************************
 * de-initialize timeout
 * 
 * in : nothing
 * out: nothing
 ************************************************************************/
void timeoutDeInit(void) {

	// stop timer	
	timer_stop(&TIMER_0);
}


/************************************************************************
 * check if timeout expired
 * 
 * in : nothing
 * out: 1=expired, 0=not expired
 ************************************************************************/
uint8_t timeoutExpired(void) {

	// check timer value against threshold (3secs with value 1500 - don't know why, should be 3000, but then the timeout is 6 secs...)	
	if( TIMER_0.time >= 3000 ) {
		return 1;

	} else {	
		return 0;
	}
}