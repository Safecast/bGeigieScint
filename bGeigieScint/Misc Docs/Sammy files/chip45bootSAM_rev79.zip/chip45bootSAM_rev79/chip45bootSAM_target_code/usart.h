/************************************************************************
 * usart.h
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * haeder file for usart.c
 ************************************************************************/


/************************************************************************
 * include header files
 ************************************************************************/
#include <stdint.h>


// make sure to include just once!
#ifndef _USART_

	#define _USART_


	/************************************************************************
	 * function prototypes
	 ************************************************************************/
	void usartInit(void);
	void usartDeInit(void);
	
	void usartPutChar(uint8_t);
	uint8_t usartGetChar(uint8_t *);


#endif
/************************************************************************/
/* end of file                                                                     */
/************************************************************************/
