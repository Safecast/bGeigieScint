/************************************************************************
 * commands.c
 *
 * chip45bootSAM versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * parsing and executing the commands received from the bootloader PC GUI
 ************************************************************************/


/************************************************************************
 * include header files
 ************************************************************************/
// #include <avr/pgmspace.h>
// #include <avr/eeprom.h>
#include <atmel_start.h>
#include <utils.h>

#include "host.h"
#include "usart.h"
#include "configure.h"
#include "commands.h"
#include "xtae.h"


/************************************************************************
 * global variables
 ************************************************************************/
// the search pattern for reading firmware version number and it's length
// full pattern with version number is "FW_VERSION:01.01", that's why we add 5 to PATTERNLENGTH sometimes later
#ifdef PROVIDE_FIRMWARE_VERSION
	const uint8_t ucFirmwarePattern[] = { "FW_VERSION:" };
	#define PATTERNLENGTH 11
#endif

// flash buffer and address variables
uint8_t flashBuffer[FLASH_PAGE_SIZE];  // a buffer as large as FLASH_PAGESIZE, since we want to buffer the full page to verify it after writing
uint8_t verifyBuffer[FLASH_PAGE_SIZE];  // a buffer as large as FLASH_PAGESIZE, since we want to buffer the full page to verify it after writing
uint32_t memoryAddress;
uint16_t flashAddressOffset;


/************************************************************************
 * parse a buffer received from the host
 *
 * in : buffer with command and length of buffer
 * out: 0   : no valid command found
 *      !=0 : received command code (see commands.h)
************************************************************************/
uint8_t commandsParseBuffer(uint8_t *buffer, unsigned int length) {
	
	uint8_t answerBuffer[HOST_BUFFER_LENGTH];  // in case new commands are being added to the protocol, check if tmpBuffer size is still sufficient


	// we always send back the receive commands (depending on success, we set the MSB below)
	answerBuffer[0] = buffer[0];
	
	// we check command byte for any known command value
	
	// host wants to read the bootloader version
	if(buffer[0] == CMD_READ_VERSION_BOOTLOADER) {
		
		answerBuffer[0] = CMD_ANS_SUCCESS;  // set success answer
		answerBuffer[1] = VERSION_MAJOR;  // major version number
		answerBuffer[2] = VERSION_MINOR;  // minor version number
		
		hostBufferSend(answerBuffer, 3);  // send back answer


	// bootloader should be exited and application firmware should be started
	// (note: the actual start happens in chip45boot3.c, since we first need to call some de-init functions)
	} else if(buffer[0] == CMD_START_APPLICATION) {

		answerBuffer[0] = CMD_ANS_SUCCESS;  // set success answer
	
		hostBufferSend(answerBuffer, 1);  // send back answer
		
		// we send one more STX character to make sure, hostDeInit() will not turn off usart before GUI has received the answer
		// this is due to usart HAL code does not provide a function to check for TXC bit...
		usartPutChar(STX);


	// set the memory start address for the upcoming flash/rww write/read commands
	} else if(buffer[0] == CMD_SET_ADDRESS) {
	
		// get flash address from the buffer
		memoryAddress = ((uint32_t)buffer[1] << 24) | ((uint32_t)buffer[2] << 16) | ((uint32_t)buffer[3] << 8) | ((uint32_t)buffer[4] << 0);

		// clear offset
		flashAddressOffset = 0;
	
		// check if address is within valid range
		if( (memoryAddress >= APPLICATION_START_ADDRESS) && (memoryAddress < FLASH_SIZE) ){
			answerBuffer[0] = CMD_ANS_SUCCESS;  // we set success answer
		} else {
			answerBuffer[0] = CMD_ANS_FAIL;  // we set success answer
		}

		// we send back the answer to the host
		hostBufferSend(answerBuffer, 1);
	
	
	#ifdef PROVIDE_FIRMWARE_VERSION

		// host wants to read the current installed firmware version
		} else if(buffer[0] == CMD_READ_VERSION_FIRMWARE) {

			uint32_t flashIndex;
			uint8_t patternIndex;
			uint16_t bufferIndex;
			uint8_t ucPatternFound;
			uint8_t tmpBuffer[FLASH_PAGE_SIZE];

			
			answerBuffer[0] = CMD_ANS_FAIL;  // preset fail answer

			// try to find a version string in the application code
			for (flashIndex = APPLICATION_START_ADDRESS; flashIndex < (FLASH_SIZE - FLASH_PAGE_SIZE); flashIndex += (FLASH_PAGE_SIZE - 16)) {

				// read one flash portion of FLASH_PAGE_SIZE
				_flash_read(&FLASH_0.dev, flashIndex, tmpBuffer, FLASH_PAGE_SIZE);

				// clear flags each time before comparing the pattern
				patternIndex = 0;
				bufferIndex = 0;
				ucPatternFound = 0;

				// loop through the buffer and check if pattern is included
				do {
					if(tmpBuffer[bufferIndex++] == ucFirmwarePattern[patternIndex]) {
						patternIndex++;  // increment pattern index
						if(patternIndex == PATTERNLENGTH) {  // if we had 11 consecutive matches, we must have found the first part of the pattern
							ucPatternFound = 1;  // set found flag
							break;  // and leave the do loop
						}
					}
					
				} while(bufferIndex < FLASH_PAGE_SIZE);  // loop as long as size of a flash page

				// if pattern was found, we can read out the version numbers
				if(ucPatternFound == 1) {
					// get the firmware version number from the buffer and write it into the host answer buffer
					answerBuffer[1] = (tmpBuffer[bufferIndex+0] - '0') * 10 + (tmpBuffer[bufferIndex+1] - '0');
					answerBuffer[2] = (tmpBuffer[bufferIndex+3] - '0') * 10 + (tmpBuffer[bufferIndex+4] - '0');
					answerBuffer[0] = CMD_ANS_SUCCESS;  // set success answer

					break;

				} else {

					// we might need to send some wait command in between to avoid timeout of the GUI when looking through large application flash
					// depends on CPU clock and flash size... with 256k flash and 16MHz it's not necessary, but just in case, we leave the code here...
					if( (flashIndex % 10000) == 0) {
						answerBuffer[3] = CMD_ANS_WAIT;  // send wait answer, since we need more time and don't want the GUI to timeout
						hostBufferSend(&answerBuffer[3], 1);  // we use a higher portion of the answer buffer for this, since we don't want to add another buffer just for this
					}
				}
			}

			// we send back the answer to the host
			hostBufferSend(answerBuffer, 3);
		
	#endif


	// writing of flash memory can be enabled/disabled in configure.h to save code space (or as -D... in project setting -> toolchain -> compiler -> symbols)
	#ifdef PROVIDE_FLASH_WRITE
	
		// host sends data for flash programming
		} else if(buffer[0] == CMD_FLASH_WRITE_DATA) {
		
			uint16_t i = 0;
			uint8_t flagWriteOk;

			--length;  // correct length

			// transfer the received data into our flash buffer (we keep it there until a full flash page of FLASH_PAGESIZE has been received)
			do {
				flashBuffer[flashAddressOffset + i] = buffer[i + 1];  // i+1, because the first byte of the buffer contains the command and no data
			} while(++i < length);
		
			// adjust address offset
			flashAddressOffset += length;
			
			// check if the address is within the application memory range
			if( ((memoryAddress + flashAddressOffset) >= (uint32_t)APPLICATION_START_ADDRESS) && ((memoryAddress + flashAddressOffset) < FLASH_SIZE) ) {
				
				flagWriteOk = 1;  // preset ok flag

				// check if the flash page is full or if we received an empty data packet to force writing of last page
				if( (flashAddressOffset >= FLASH_PAGE_SIZE) || (length == 0) ) {
			
					// if we received XTAE encrypted flash data, we need to decrypt it first
					#ifdef USE_ENCRYPTION
						xtaeDecryptBuffer(flashBuffer, flashAddressOffset);  // decrypt the buffer, see xtae.c for details
					#endif
			
					// then we write the buffer to flash and verify the actual flash content against our buffer
					_flash_write(&FLASH_0.dev, memoryAddress, flashBuffer, flashAddressOffset);

					// and read back into another buffer for verify
					_flash_read(&FLASH_0.dev, memoryAddress, verifyBuffer, flashAddressOffset);

					// verify both buffers
					for(i = 0; i < flashAddressOffset; ++i) {

						if(flashBuffer[i] != verifyBuffer[i]) {						
							flagWriteOk = 0;  // verify error, clear OK flag!
							break;
						}
					}

					memoryAddress += flashAddressOffset;  // add the offset to the address
					flashAddressOffset = 0;  // clear offset
				}
				
			} else {  // address is either inside bootloader or above existing flash memory
				
				flagWriteOk = 0;  // if not, we clear that flag to indicate an error
			}
				
			// check if we had a verify error or the address was outside valid application memory
			if(flagWriteOk == 1) {
				answerBuffer[0] = CMD_ANS_SUCCESS;  // set success answer
			} else {
				answerBuffer[0] = CMD_ANS_FAIL;  // set fail answer
			}

			// we send back the answer to the host
			hostBufferSend(answerBuffer, 1);
			
	#endif  // COMMAND_FLASH_WRITE	
		
		
	// reading of flash memory can be enabled/disabled in configure.h to save code space (or as -D... in project setting -> toolchain -> compiler -> symbols)
	// (note: for security reasons flash reading should be disabled if the bootloader is used with encrypted transmission!)
	#ifdef PROVIDE_FLASH_READ
	
		// host wants to read a 64 byte packet of flash data
		// (note: depending of address, we might not be able to read full 64 bytes, if so, we just send less, the host takes care of this)
		} else if(buffer[0] == CMD_FLASH_READ_DATA) {

			uint8_t length = 0;  // clear buffer length counter
			uint8_t count = buffer[1];  // get number of bytes to read from buffer
			
			// maximum number of bytes to read is 64, due to buffer size and CRC constraints
			if(count > 64) {
				count = 64;  // crop to 64 bytes, if larger number was specified
			}

			// set MSB in command byte to indicates success
			answerBuffer[0] = CMD_ANS_SUCCESS;  // set success answer
				
			// check if we are still within valid flash memory address range
			if((memoryAddress + count) < FLASH_SIZE) {

				// check if we are above bootloader area
				if(memoryAddress >= APPLICATION_START_ADDRESS) {  // if so, we actually read from flash

					// read 64 bytes from flash and put into buffer
					_flash_read(&FLASH_0.dev, memoryAddress, &answerBuffer[1], count);  // we start writing to index 1 of the buffer, since the first byte contains the command byte

					length += count;

					// increment memory address
					memoryAddress += count;

				} else {  // if not, we fill the buffer with 0xff's

					// increment memory address
					memoryAddress += count;

					// and fill buffer with 0xff
					while(count--) {
						answerBuffer[length++] = 0xff;
					}
				}
				
			
			} else {
				
				// nothing to do here, since we didn't read anything and GUI will stop reading if an empty packet was sent back
			}
			
			// we send back the answer to the host
			hostBufferSend(answerBuffer, length);
			
	#endif  // COMMAND_FLASH_READ
	
	
	// didn't find a valid command
	} else {

		return 0;  // error
	}


	// found a valid command and did execute it
	return buffer[0];  // we return the command code, so that the main program can also do something accordingly
}
