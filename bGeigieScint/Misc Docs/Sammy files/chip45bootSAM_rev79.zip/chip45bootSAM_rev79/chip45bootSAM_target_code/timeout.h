/************************************************************************
 * timeout.c
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * timeout functions
 ************************************************************************/

#include <atmel_start.h>

#ifndef TIMEOUT_H_

	#define TIMEOUT_H_


	// function prototypes
	void timeoutInit(void);
	void timeoutDeInit(void);

	uint8_t timeoutExpired(void);


#endif /* TIMEOUT_H_ */