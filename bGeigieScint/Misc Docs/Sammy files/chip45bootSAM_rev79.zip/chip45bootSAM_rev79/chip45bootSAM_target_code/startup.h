/************************************************************************
 * startup.h
 *
 * chip45boot3 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * header file for startup.c
 ************************************************************************/


#ifndef STARTUP_H_

	#define STARTUP_H_


	/************************************************************************
	 * function prototypes
	 ************************************************************************/
	 uint8_t startupCheckStartCondition(void);


#endif /* STARTUP_H_ */
