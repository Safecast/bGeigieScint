/************************************************************************
 * chip45boot4.h
 *
 * chip45boot4 versatile Atmel/Microchip SAM bootloader
 *
 * (c) 2018, Dr. Erik Lins, chip45 GmbH u. Co. KG
 * info@chip45.com, http://www.chip45.com
 *
 * USART communication functions
 ************************************************************************/


#ifndef CHIP45BOOT4_H_
#define CHIP45BOOT4_H_

void userMain(void);

#endif /* CHIP45BOOT4_H_ */

// end of file: chip45boot4.h
