#include <atmel_start.h>

#include <chip45bootSAM.h>


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	// start bootloader
	userMain();
	
	/* Replace with your application code */
	while (1) {
	}
}
