xtae.d xtae.o: ../../../chip45bootSAM_target_code/xtae.c \
 ../../../chip45bootSAM_target_code/configure.h

../../../chip45bootSAM_target_code/configure.h:
