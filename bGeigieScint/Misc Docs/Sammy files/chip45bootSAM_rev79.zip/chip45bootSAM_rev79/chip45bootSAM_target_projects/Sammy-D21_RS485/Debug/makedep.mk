################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

..\..\chip45bootSAM_target_code\autobaud.c

..\..\chip45bootSAM_target_code\chip45bootSAM.c

..\..\chip45bootSAM_target_code\commands.c

..\..\chip45bootSAM_target_code\crc.c

..\..\chip45bootSAM_target_code\host.c

..\..\chip45bootSAM_target_code\startup.c

..\..\chip45bootSAM_target_code\timeout.c

..\..\chip45bootSAM_target_code\usart.c

..\..\chip45bootSAM_target_code\xtae.c

atmel_start.c

Device_Startup\startup_samd21.c

Device_Startup\system_samd21.c

driver_init.c

hal\src\hal_atomic.c

hal\src\hal_delay.c

hal\src\hal_flash.c

hal\src\hal_gpio.c

hal\src\hal_init.c

hal\src\hal_io.c

hal\src\hal_sleep.c

hal\src\hal_timer.c

hal\utils\src\utils_assert.c

hal\utils\src\utils_event.c

hal\utils\src\utils_list.c

hal\utils\src\utils_syscalls.c

hpl\core\hpl_core_m0plus_base.c

hpl\core\hpl_init.c

hpl\dmac\hpl_dmac.c

hpl\gclk\hpl_gclk.c

hpl\nvmctrl\hpl_nvmctrl.c

hpl\pm\hpl_pm.c

hpl\sysctrl\hpl_sysctrl.c

hpl\tc\hpl_tc.c

hpl\usart\usart_lite.c

main.c

